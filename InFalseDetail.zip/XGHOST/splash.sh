#!/usr/bin/env bash
#sudo update-alternatives --config default.plymouth
sudo update-initramfs -u
